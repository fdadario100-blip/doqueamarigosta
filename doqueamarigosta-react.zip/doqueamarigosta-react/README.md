# Do que a Mari gosta? - Vite + React (PWA ready)

Este é o projeto pronto para deploy na **Vercel**. O app roda em modo *single page* e usa codificação no link para compartilhar respostas (sem servidor).

## Como publicar no Vercel (passo a passo rápido)

Opção A — CLI / Git (recomendado)
1. Faça um repositório no GitHub e envie este código.
2. Acesse https://vercel.com, crie uma conta e conecte o repositório.
3. Escolha o repositório e clique em Deploy. Vercel detecta o projeto Vite e faz o build automaticamente.
4. Após o deploy você terá um domínio do tipo `https://seu-projeto.vercel.app`.

Opção B — Fazer upload do ZIP (mais simples)
1. No Vercel, crie um novo projeto e escolha a opção de importar de **'Other'** ou envie o ZIP.
2. Siga as instruções, Vercel executará `npm install` e `npm run build`.
3. Pronto — você terá o link público.

## Uso local (para testar)
1. Instale dependências:
   ```bash
   npm install
   ```
2. Rode em modo dev:
   ```bash
   npm run dev
   ```
3. Abra o endereço que o Vite indicar (ex: http://localhost:5173)

## Observações
- O app funciona sem backend: para gerar um formulário o app gera um link que você envia para outra pessoa. Quando ela responder, o app gera um link de resposta que pode ser aberto para visualizar as respostas.
- Para transformar em versão com backend (salvamento em servidor), recomendo Firebase / Supabase. Posso ajudar com isso depois.
