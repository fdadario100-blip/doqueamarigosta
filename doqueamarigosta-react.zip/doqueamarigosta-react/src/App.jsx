import React, { useEffect, useState } from "react";

const QUESTIONS = [
  // 1-10 Gostos e Preferências
  { id: 1, q: "Prefere praia ou montanha?", opts: ["Praia", "Montanha", "As duas", "Nenhuma"] },
  { id: 2, q: "Gosta mais de doce ou salgado?", opts: ["Doce", "Salgado", "Depende do momento"] },
  { id: 3, q: "Prefere café ou chá?", opts: ["Café", "Chá", "Nenhum"] },
  { id: 4, q: "Gosta de animais de estimação?", opts: ["Sim, amo", "Gosto, mas não tenho", "Não muito"] },
  { id: 5, q: "Curte filmes de terror?", opts: ["Sim", "Às vezes", "Não"] },
  { id: 6, q: "É mais caseiro(a) ou gosta de sair?", opts: ["Caseiro(a)", "Gosto de sair", "Depende do humor"] },
  { id: 7, q: "Prefere Netflix ou rolê com amigos?", opts: ["Netflix", "Rolê com amigos", "Depende"] },
  { id: 8, q: "Gosta de música sertaneja?", opts: ["Sim", "Não", "Um pouco"] },
  { id: 9, q: "Prefere viajar de carro ou avião?", opts: ["Carro", "Avião", "Tanto faz"] },
  { id: 10, q: "Gosta de cozinhar?", opts: ["Sim", "Às vezes", "Não"] },

  // 11-18 Estilo de Vida
  { id: 11, q: "Costuma acordar cedo?", opts: ["Sim", "Só quando preciso", "Nunca"] },
  { id: 12, q: "Faz exercícios regularmente?", opts: ["Sim", "Às vezes", "Não"] },
  { id: 13, q: "Fuma ou bebe?", opts: ["Só bebo", "Só fumo", "Ambos", "Nenhum"] },
  { id: 14, q: "Curte aventuras ao ar livre?", opts: ["Sim", "Depende da aventura", "Prefiro lugares tranquilos"] },
  { id: 15, q: "Valoriza rotina ou prefere improvisar?", opts: ["Rotina", "Improvisar", "Um equilíbrio"] },
  { id: 16, q: "Gosta de ler livros?", opts: ["Sim", "Às vezes", "Não muito"] },
  { id: 17, q: "Se considera organizado(a)?", opts: ["Sim", "Mais ou menos", "Bagunceiro(a)"] },
  { id: 18, q: "Costuma ser pontual?", opts: ["Sempre", "Às vezes atraso", "Nunca no horário 😅"] },

  // 19-25 Personalidade e Valores
  { id: 19, q: "É mais introvertido(a) ou extrovertido(a)?", opts: ["Introvertido(a)", "Extrovertido(a)", "Depende do ambiente"] },
  { id: 20, q: "Se considera romântico(a)?", opts: ["Sim", "Às vezes", "Não muito"] },
  { id: 21, q: "Gosta de surpresas?", opts: ["Sim", "Às vezes", "Não gosto"] },
  { id: 22, q: "Prefere planejar ou deixar acontecer?", opts: ["Planejar", "Deixar acontecer", "Um pouco dos dois"] },
  { id: 23, q: "É ciumento(a)?", opts: ["Sim", "Um pouco", "Nada"] },
  { id: 24, q: "Se considera calmo(a) ou impaciente?", opts: ["Calmo(a)", "Impaciente", "Depende da situação"] },
  { id: 25, q: "Valoriza mais estabilidade ou emoção?", opts: ["Estabilidade", "Emoção", "Equilíbrio"] },

  // 26-30 Sonhos e Curiosidades
  { id: 26, q: "Tem vontade de morar em outro país?", opts: ["Sim", "Talvez", "Não"] },
  { id: 27, q: "Gosta de aprender coisas novas?", opts: ["Sim", "Só se for algo que gosto", "Não muito"] },
  { id: 28, q: "Tem algum medo estranho?", opts: ["Sim", "Talvez 😅", "Não"] },
  { id: 29, q: "Qual seria o destino ideal de uma viagem dos sonhos?", opts: ["Praia paradisíaca", "Cidade grande", "Montanha", "Europa clássica"] },
  { id: 30, q: "O que mais te faz sorrir?", opts: ["Boa companhia", "Música", "Comida", "Momentos simples"] }
];

function encodePayload(obj) {
  try {
    return encodeURIComponent(btoa(JSON.stringify(obj)));
  } catch (e) {
    console.error("Encode error", e);
    return "";
  }
}

function decodePayload(str) {
  try {
    return JSON.parse(atob(decodeURIComponent(str)));
  } catch (e) {
    return null;
  }
}

export default function App() {
  const [mode, setMode] = useState("home"); // home | create | fill | view
  const [responses, setResponses] = useState({});
  const [ownerLink, setOwnerLink] = useState("");
  const [responseLink, setResponseLink] = useState("");
  const [senderName, setSenderName] = useState("");
  const [responderName, setResponderName] = useState("");
  const [title] = useState("Do que a Mari gosta?");
  const [subtitle] = useState("Descubra o que temos em comum");

  useEffect(() => {
    // on load, check URL param ?data=
    const params = new URLSearchParams(window.location.search);
    const encoded = params.get("data");
    if (encoded) {
      const payload = decodePayload(encoded);
      if (payload && payload.type === "form") {
        if (payload.senderName) setSenderName(payload.senderName);
        setMode("fill");
      } else if (payload && payload.type === "response") {
        if (payload.responderName) setResponderName(payload.responderName);
        if (payload.responses) setResponses(payload.responses);
        setMode("view");
      }
    }
  }, []);

  function toggle(qid, optIdx) {
    setResponses(prev => {
      const cur = prev[qid] || [];
      // toggle selection (allow multiple? We made single-choice; so set array with single index)
      return { ...prev, [qid]: [optIdx] };
    });
  }

  function generateFormLink() {
    const payload = { type: "form", senderName };
    const enc = encodePayload(payload);
    const link = `${window.location.origin}${window.location.pathname}?data=${enc}`;
    setOwnerLink(link);
    return link;
  }

  function generateResponseLink() {
    const payload = {
      type: "response",
      responderName,
      responses
    };
    const enc = encodePayload(payload);
    const link = `${window.location.origin}${window.location.pathname}?data=${enc}`;
    setResponseLink(link);
    return link;
  }

  function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
      alert("Link copiado para a área de transferência");
    }).catch(() => alert("Não foi possível copiar o link"));
  }

  if (mode === "home") {
    return (
      <div className="wrap">
        <header className="card">
          <h1 className="title">{title}</h1>
          <p className="subtitle">{subtitle}</p>
        </header>

        <main className="card">
          <p>Crie um link do formulário e envie para alguém responder.</p>
          <label className="label">Seu nome (opcional)</label>
          <input className="input" value={senderName} onChange={e => setSenderName(e.target.value)} placeholder="Ex: Mari" />
          <div className="row">
            <button className="btn primary" onClick={() => { generateFormLink(); setMode("create"); }}>Gerar link do formulário</button>
            <button className="btn" onClick={() => setMode("fill")}>Abrir como quem responde</button>
          </div>

          {ownerLink && (
            <div className="box">
              <div className="small">{ownerLink}</div>
              <div className="row">
                <button className="btn" onClick={() => copyToClipboard(ownerLink)}>Copiar link</button>
                <a className="btn" href={ownerLink}>Abrir link</a>
              </div>
            </div>
          )}
        </main>

        <footer className="foot">Feito com ♥ — “Do que a Mari gosta?”</footer>
      </div>
    );
  }

  if (mode === "create") {
    return (
      <div className="wrap">
        <header className="card"><h1 className="title">{title}</h1></header>
        <main className="card">
          <p>Link do formulário gerado — envie para quem vai responder.</p>
          <div className="box">
            <div className="small">{ownerLink}</div>
            <div className="row">
              <button className="btn" onClick={() => copyToClipboard(ownerLink)}>Copiar</button>
              <a className="btn" href={ownerLink}>Abrir</a>
            </div>
            <div style={{marginTop:12}}>
              <button className="btn" onClick={() => setMode("home")}>Voltar</button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (mode === "fill") {
    return (
      <div className="wrap">
        <header className="card"><h1 className="title">{title}</h1><p className="subtitle">Responda o checklist</p></header>
        <main className="card scroll">
          {senderName && <div className="small">Formulário enviado por: <strong>{senderName}</strong></div>}
          <label className="label">Seu nome (quem responde) — opcional</label>
          <input className="input" value={responderName} onChange={e => setResponderName(e.target.value)} placeholder="Ex: João" />
          <div style={{marginTop:8}}>
            {QUESTIONS.map(q => (
              <div key={q.id} className="qcard">
                <div className="qtitle">{q.q}</div>
                <div className="opts">
                  {q.opts.map((o, idx) => {
                    const checked = (responses[q.id] || []).includes(idx);
                    return (
                      <label key={idx} className={"opt "+(checked?"checked":"")}>
                        <input type="radio" name={"q"+q.id} checked={checked} onChange={() => toggle(q.id, idx)} />
                        <span>{o}</span>
                      </label>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>

          <div className="row">
            <button className="btn primary" onClick={() => { generateResponseLink(); alert('Link de resposta gerado — copie e envie para quem criou o formulário.'); }}>Enviar e gerar link de resposta</button>
            <button className="btn" onClick={() => setMode("home")}>Cancelar</button>
          </div>

          {responseLink && (
            <div className="box">
              <div className="small">{responseLink}</div>
              <div className="row">
                <button className="btn" onClick={() => copyToClipboard(responseLink)}>Copiar link</button>
                <a className="btn" href={responseLink}>Abrir link</a>
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }

  // view mode
  return (
    <div className="wrap">
      <header className="card"><h1 className="title">{title}</h1><p className="subtitle">Respostas</p></header>
      <main className="card scroll">
        {responderName && <div className="small">Respondido por: <strong>{responderName}</strong></div>}
        {QUESTIONS.map(q => {
          const sel = (responses[q.id] || [])[0];
          return (
            <div key={q.id} className="qcard">
              <div className="qtitle">{q.q}</div>
              <div className="small">Resposta: <strong>{sel !== undefined ? q.opts[sel] : "Não respondido"}</strong></div>
            </div>
          )
        })}
        <div className="row" style={{marginTop:12}}>
          <button className="btn" onClick={() => setMode("home")}>Voltar</button>
        </div>
      </main>
    </div>
  );
}
